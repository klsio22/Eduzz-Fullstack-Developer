let n = 0
let x =0;

while(n < 3){
  x += n
  x++
  console.log(x)
}

console.log(x)

