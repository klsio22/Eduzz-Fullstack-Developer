let i = 0;

do {
  i++;
  console.log(i);
} while (i < 5);
