const array = ["one","two",'Thee']

for (let i = 0 ; i < array.length; i++){
  const element = array[i];
  console.log(`Element ${i} : ${element}`)
}
