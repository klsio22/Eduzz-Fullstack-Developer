//Móulo (%)
//Operador binario . Retorna o inteiro restante da divisão dos dois operandos.

12 % 5 //retorna 2

// Incremento (++) e decrenebti (--)

++x
x++

const a = ++2 // Adiciona + 1
const b = 2++ // retorna do atual

-3
+"3" //retorna 3 
+true // retorna 1
-false // retorna 0
-true //retorna -1

//Operador de exponenciação(**)
2**3
10 ** -1

