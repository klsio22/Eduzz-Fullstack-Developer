const {getName,setName} = require('./5-module.js')

console.log(getName())
console.log(setName('Alyce'))//setName não retorna nada
console.log(getName())