let partes = ["Ombro", "joelhos"];
let musicas = ["cabeça", ...partes, "e", "pés"];
//... para implementar os elementos de uma arry dentro da outra

console.log(musicas);

function fn(x, y, z) {
}

let args = [0, 1, 2];
fn(...args);

console.log(fn(...args))