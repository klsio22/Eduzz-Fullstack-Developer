/* Vai listar todos os as divs da pagina */

const divs = document.querySelectorAll('div')

//Transforma as NodeList em arrays 
const arr = Array.from(divs);

