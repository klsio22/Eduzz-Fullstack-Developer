 const div = () => console.log("--".repeat(20));

 //export default div; // ES6

 module.exports = {
   div
 }