interface JQuery {
  newFunction(): void;
}