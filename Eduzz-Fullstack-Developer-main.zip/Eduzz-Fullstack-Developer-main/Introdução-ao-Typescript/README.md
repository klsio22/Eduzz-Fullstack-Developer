### para rodar o typescript 

`yarn add parce-bundler para instaler um server na maquina`

### Para exetudar o projeto 

`yarn parcel index.html`

### Instalar typagens do typescript (ts2+) do jquery

`npm install --save-dev @types/jquery`